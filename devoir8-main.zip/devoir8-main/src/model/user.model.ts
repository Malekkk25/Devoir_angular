
export class User{
    username:string | undefined ;
    password: string | undefined ;
    roles:string[] | undefined;
    }