export class produit{
    idProduit? :number;
    nomProduit? : string;
    prixProduit?:number;
    dateCreation?:Date;
}