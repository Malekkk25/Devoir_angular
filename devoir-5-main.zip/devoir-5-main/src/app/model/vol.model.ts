export class Vol {
    idVol? : String;
    agence? : string;
    Depart? : string ;
    minuteDepart? : number ;
    destination?:string;
    etat?:string;
    terminal?:string;
    }